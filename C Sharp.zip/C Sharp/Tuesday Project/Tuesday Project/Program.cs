﻿using System;

namespace Tuesday_Project
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Print Screen");
        }
    }
}
