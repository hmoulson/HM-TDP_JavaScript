﻿using System;

namespace C_Sharp___Salary_Mk2
{
    class Program
    {
        static void Main(string[] args)
        {
            float tax,net;
            int salary;
            tax=0;
            net=0;
            salary=300;
            if(salary>=1000){
                if(salary>=2000){
                    tax=(float) 0.25*salary;
                }
                else{
                    tax=(float) 0.15*salary;
                }
            }
            else {
                tax=(float) 0*salary;
            }
            net=(float) salary-tax;
            Console.Write("Salary is ");
            Console.WriteLine(salary);
            Console.Write("Tax is ");
            Console.WriteLine(tax);
            Console.Write("Take Home Pay is ");
            Console.WriteLine(net);
        }
    }
}
