﻿using System;

namespace C_Sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello ");
            Console.WriteLine("My ");
            Console.WriteLine("Friends");
            Console.WriteLine("This is NBS");
        }
    }
}
