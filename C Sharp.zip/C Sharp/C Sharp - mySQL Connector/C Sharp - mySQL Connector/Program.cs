﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp___mySQL_Connector
{
    class Program
    {
        static void Main(string[] args)
        {
            long telephone;
            String postcode, name;

            name = "Lili Abbott";
            telephone = 07396830212;
            postcode = "SN1 4AN";

            string library = "nbs_qa2";
            string searchname = "Lyla New";

            string telephone_num = telephone.ToString();
            Talking_to_SQL talk = new Talking_to_SQL();
            talk.datastore(name,telephone_num,postcode);
            talk.displaydata();
            //talk.filterdata();
            //talk.searchbyname(searchname);
            //talk.salaryrange(35000,43000);
        }
    }
}
