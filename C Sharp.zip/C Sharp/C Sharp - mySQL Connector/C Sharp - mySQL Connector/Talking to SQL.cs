﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___mySQL_Connector
{
    class Talking_to_SQL
    {
        MySqlConnection sqlcon;
        MySqlCommand cmd;

        public Talking_to_SQL()
        {
            String ConnectionString = "Server=localhost;user=root;password=root;database=library";
            sqlcon = new MySqlConnection(ConnectionString);
            sqlcon.Open();
            cmd = new MySqlCommand();
            cmd.Connection = sqlcon;
        }
        
        public void datastore(string name,string telephone,string postcode)
        {
            String SQLOperation = $"Insert into Members(name,telephone,postcode) values('{name}','{telephone}','{postcode}')";
            cmd.CommandText = SQLOperation;
            cmd.ExecuteNonQuery();
        }

        public void displaydata()
        {
            string SQLSelect = "Select * from book_inventory";
            cmd.CommandText = SQLSelect;
            MySqlDataReader data = cmd.ExecuteReader();

            while (data.Read())
            {
                Console.WriteLine(data[0] + "....." + data[1] + "....." + data[2] + "....." + data[3]);
            }

            Console.Read();
        }

        public void filterdata()
        {
            string SQLSelect = "Select * from book_inventory where book_ref = 103";
            cmd.CommandText = SQLSelect;
            MySqlDataReader data = cmd.ExecuteReader();

            while(data.Read())
            {
                Console.WriteLine(data[0] + "....." + data[1] + "....." + data[2] + "....." + data[3]);
            }

            Console.Read();
        }

        public void searchbyname(string name)
        {
            string SQLchoose = "Select * from consultants where name ='{name}'";
            cmd.CommandText = SQLchoose;
            MySqlDataReader data = cmd.ExecuteReader();

            while (data.Read())
            {
                Console.WriteLine(data[0] + "....." + data[1] + "....." + data[2]);
            }

            Console.Read();
        }

        public void salaryrange(int low,int high)
        {
            string SQLchoose = "Select * from consultants where salary>= {low} and salary<= {high}";
            showRecords(SQLchoose);
        }

        private void showRecords(string SQLmove)
        {
            cmd.CommandText=SQLmove;
            MySqlDataReader data = cmd.ExecuteReader();
            while (data.Read())
            {
                Console.WriteLine(data[0] + "....." + data[1] + "....." + data[2]);
            }

            Console.Read();
        }
    }
}
