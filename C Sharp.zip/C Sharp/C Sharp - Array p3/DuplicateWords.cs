using System;
using System.Collections; //allows ArrayList to be used

class DuplicateWords
{
    ArrayList Words=new ArrayList();
    //requires System.Collection to be added to work
    public void removeDuplicates(string message)
    {
        int i;
        string word = "";
        string newmessage="";

        for(i=0;i<message.Length;i++)
        {
            if(message.Substring(i,1)==" "||message.Substring(i,1)==","||message.Substring(i,1)==".")
            // || allows or string that removes punctuation from substrings
            {
                if(checkWord(word)==true) //checkWord showing the word is unique
                {
                    newmessage+=" "+word;
                    word="";
                }
                else{
                    word="";
                }
            }
            else
            {
                word+=message.Substring(i,1);
            }
        }

        Console.WriteLine(newmessage);
        /*
        for(i=0;i<Words.Count;i++)
        {
            Console.WriteLine(Words[i]);
        }
        */

    }

    private bool checkWord(string w) //bool returns true/false
    {
        int x;
        for (x=0;x<Words.Count;x++) //compares x against number of stored elements in Words)
        {
            if(w==(String)Words[x]||w=="") //the "" removes empty versions of w created by punctuation in messages
            {
                return false;
            }
            else
            {
                continue;
            }
        }
        Words.Add(w); //adds w as new element in Words Array
        return true;

    }

}