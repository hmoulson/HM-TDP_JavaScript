﻿using System;

namespace C_Sharp___Array_p3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            DuplicateWords dup=new DuplicateWords();
            string message = "it was the best of times, it was the worst of times.";
            dup.removeDuplicates(message);
            */

            NumberArray numberArray=new NumberArray();
            numberArray.display();
        }
    }
}