using System;

class NumberArray
{
    int[] num={1,2,3,4,5,6,7,8,9,10};
    int i;
    int j;
    public void display()
    {    
        for(i=0;i<num.Length;i++)
        {
            string display="";
            for(j=0;j<=i;j++)
            {
                if(j==0)
                {
                    display+=num[j];
                }
                else
                {
                    display+=","+num[j];
                }
            }
            Console.WriteLine(display+".");
        }
    }






}