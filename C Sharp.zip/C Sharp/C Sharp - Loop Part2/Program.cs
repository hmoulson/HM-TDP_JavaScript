﻿using System;

namespace C_Sharp___Loop_Part2
{
    class Program
    {
        static void Main(string[] args)
        {
            int A,B,C;
            A=1;
            B=2;
            C=300;
            for(;A<=10;A++,B+=2){
                if(B<8){
                    continue;
                }
                if(A==8){
                    break;
                }
                Console.WriteLine(A+"..."+B+"..."+C);
            }
            for(;C>=10;A+=3,B+=14,C/=2){
                if(A>24){
                    break;
                }
                Console.WriteLine(A+"..."+B+"..."+C);
            }

        }
    }
}
