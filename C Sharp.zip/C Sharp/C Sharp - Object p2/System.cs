using System;

class Calculations
{
    public void workstream(int e,int f,int g,int h)
    {
        int Result;
        Result = e+f+g+h;
        Console.WriteLine("result is "+Result);
    }


}