﻿using System;

namespace C_Sharp___Object_p2
{
    internal class NewBaseType
    {
        static void Main(string[] args)
        {
            int j,k;
            j=24;
            k=19;
            
            Nationwide X;
            X = new Nationwide();
            X.a = 86;
            X.b = 63;
            X.showResults();
            Console.WriteLine("--------");
            X.insertingvalues(j,k);
            Console.WriteLine("--------");

            Calculations calc;
            calc=new Calculations();
            calc.workstream(X.a,X.b,j,k);
        }
    }

    class Nationwide
    {
        public int a,b,c;
        public void showResults()
        {
            for(;a<=90;a++,b-=12)
            {
               Console.WriteLine("C equals total of "+a+"+"+b);
                c=a+b;
                Console.WriteLine("Result is "+c); 
            }
        }
        public void insertingvalues(int x,int y)
        {
            int z;
            z=x+y;
            Console.WriteLine("x="+x);
            Console.WriteLine("y="+y);
            Console.WriteLine("z="+z);
        }
    }
}
