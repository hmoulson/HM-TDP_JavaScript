﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using MySql.Data.MySqlClient;

namespace C_Sharp___Files_p._2
{
    class Deduplicating_Files
    {
        ArrayList Words = new ArrayList();
        public string dedup(string text)
        {
            int i;
            string dedupwords = "";
            string newword = "";
            for (i = 0; i < text.Length; i++)
            {
                if (text.Substring(i, 1) == " " || text.Substring(i, 1) == "," || text.Substring(i, 1) == ".")
                {
                    if (checkWord(newword) == true)
                    {
                        dedupwords += " " + newword;
                        newword = "";
                    }
                    else
                    {
                        newword = "";
                    }
                }
                else
                {
                    newword += text.Substring(i, 1);
                }
            }
            return dedupwords;
        }

        private bool checkWord(string w)
        {
            int x;
            for (x = 0; x < Words.Count; x++)
            {
                if (w == (String)Words[x] || w == "")
                {
                    return false;
                }
                else
                {
                    continue;
                }
            }
            Words.Add(w);
            return true;
        }

    }
}