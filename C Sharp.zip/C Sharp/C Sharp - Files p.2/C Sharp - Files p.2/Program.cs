﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using MySql.Data.MySqlClient;


namespace C_Sharp___Files_p._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the filename");
            string filename = Console.ReadLine();
            string ReadText = File.ReadAllText(@"C:\Users\Admin\Desktop\"+filename);

            WordCount wordCount = new WordCount();
            int num = wordCount.wordcount(ReadText);

            Console.WriteLine("The total number of words in " + filename + " is " + (num + 1));


            Deduplicating_Files deduplicating = new Deduplicating_Files();
            String NewText = deduplicating.dedup(ReadText);
            string filename_2 = filename + "_2";
            File.WriteAllText(@"C:\Users\Admin\Desktop\"+filename_2, NewText);


            Console.WriteLine("Your deduplicated file is: " + filename_2);
            int numdedup = wordCount.wordcount(ReadText);

            Console.WriteLine("The total number of unique words in " + filename + " is " + (numdedup));
            Console.WriteLine("These an be seen in your deduplicated file found here: " + filename_2);
            Console.Read();


        }
    }
}