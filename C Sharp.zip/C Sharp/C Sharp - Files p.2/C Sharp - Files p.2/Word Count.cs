﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using MySql.Data.MySqlClient;

namespace C_Sharp___Files_p._2
{
    class WordCount
    {
        int number;
        public int wordcount(string text)
        {
            int i;
            
            for (i = 0; i < text.Length; i++)
            {
                if (text.Substring(i,1) == " ")
                {
                    number = number+1;
                }
            }
            return number;
        }
    }
}
