﻿using System;

namespace C_Sharp___Task
{
    class Program
    {
        static void Main(string[] args)
        {
            QATask t=new QATask();
            
            
            int Enter = 1625;
            t.check(Enter);

            int Bill=232;
            int Paid=300;
        
            t.BalanceDetails(Bill,Paid);

            int Value=427;
            t.NumCharacters(Value);

            int VariableA=42;
            int VariableB=37;
            t.integerswitch(VariableA,VariableB);
        }
    }

}
