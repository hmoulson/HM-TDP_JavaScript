using System;

 class QATask
{
    public void check(int num)
    {
        Console.WriteLine("");
        Console.WriteLine("If/Else Map");
        Console.WriteLine("");

        Console.WriteLine("Your Value is: "+num);
        if(num>1000)
        {
            Console.WriteLine("A");
            if(num>2000)
            {
                Console.WriteLine("C");
                if(num>4000)
                {
                    Console.WriteLine("E");
                }
                else
                {
                    Console.WriteLine("F");
                }
                Console.WriteLine("J");
            } 
            else
            {
                Console.WriteLine("D");
            }
        }
        else
        {
            Console.WriteLine("B");
            if(num>500)
            {
                Console.WriteLine("K");
                Console.WriteLine("M");
                if(num>700)
                {
                    Console.WriteLine("O");
                }
                else
                {
                    Console.WriteLine("N");
                }
                Console.WriteLine("P");
            }
            else
            {
                Console.WriteLine("L");
            }
            Console.WriteLine("");
        }
    }

    public void BalanceDetails(int Bill,int Paid)
    {
        Console.WriteLine("----------------");
        Console.WriteLine("");
        Console.WriteLine("Bill Balance");
        Console.WriteLine("");
        
        int Balance = Paid-Bill;
        Console.WriteLine("Bill "+Bill+" ----- Paid "+Paid);
        Console.WriteLine("Change "+Balance);

        if(Balance>0)
            {
                int Denomination;
                if(Balance>50)
                {
                    Denomination=50;
                    Console.Write(Denomination+": ");
                    Console.WriteLine(Balance/Denomination);
                    Balance%=Denomination;
                }
                
                for(Denomination=20;Denomination>=1;Denomination/=2)
                {
                    if(Balance<Denomination)
                    {
                        continue;
                    }
                    Console.Write(Denomination+": ");
                    Console.WriteLine(Balance/Denomination);
                    Balance%=Denomination;
                }
            }
        else
        {
            Console.WriteLine("No Change Required");
        }
    Console.WriteLine("");
    }
    public void NumCharacters(int num2)
    {
        Console.WriteLine("----------------");
        Console.WriteLine("");
        Console.WriteLine("Number Character Summer");
        Console.WriteLine("");
        
        Console.WriteLine("Your number is: "+num2);
        Console.WriteLine((num2/100)+((num2%100)/10)+((num2%100)%10));
        
        Console.WriteLine("");
    }
    public void integerswitch(int A,int B)
    {
        Console.WriteLine("----------------");
        Console.WriteLine("");
        Console.WriteLine("Integer Switcher");
        Console.WriteLine("");
        
        Console.WriteLine("Your variables were:");
        Console.WriteLine("A - "+A+"     B - "+B);
        int C=B;
        B=A;
        A=C;
        Console.WriteLine("Your variables now are:");
        Console.WriteLine("A - "+A+"     B - "+B);
        
        Console.WriteLine("");
    }
}