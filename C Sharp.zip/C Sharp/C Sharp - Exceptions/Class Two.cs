using System;

class Two
{
    public One X;
    public Two()
    {
        X = new One();
    }
}