﻿using System;

namespace C_Sharp___Exceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            /*int[] numbers={1,5};
            try
            {
                Console.WriteLine(numbers[2]);
                Console.WriteLine("Testing");
            }
            catch(IndexOutOfRangeException IORE)
            {
                Console.Write("Test Error");
            }
            */

            Three Z=new Three();
            Z.Y.X.msg1();
        }
    }
}
