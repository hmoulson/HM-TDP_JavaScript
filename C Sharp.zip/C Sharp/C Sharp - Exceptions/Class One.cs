using System;

class One
{
    public void msg1()
    {
        int[] Num={6/2};
        try{
        Console.Write("The result of the ask is "+Num[0]);
        }
        catch(IndexOutOfRangeException IORE){
            Console.WriteLine("Error Message");
        }
        finally
        {
            Console.WriteLine("Testing");
        }
    }


}