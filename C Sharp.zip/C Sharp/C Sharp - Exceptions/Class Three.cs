using System;

class Three
{
    public Two Y;
    public Three()
    {
        Y = new Two();
    }
}