using System;


class ArrayBasic
{
    public int[] numbers = {-72,-64,-97,-79,-83,-158,-68,-76,-86,-68,-93,-68,-108,-104};
    public int num;
    public int secnum=0;
    int index_num;
    int index_sec;

    public void StarterArray()
    {
        Console.WriteLine("testing");
        num=numbers[0];
        int i=0;
        for(;i<numbers.Length;i++)
        {
            if(num<(-1*numbers[i]))
            {
                index_sec=index_num;
                secnum=num;
                index_num=i;
                num=(-1*numbers[i]);
            }
            else if(secnum<(-1*numbers[i]))
            {
                secnum=(-1*numbers[i]);
                index_sec=i;
            }
        }
        num=numbers[index_num];
        secnum=numbers[index_sec];
        Console.WriteLine("largest value - "+num);
        Console.WriteLine("second value - "+secnum);
    }

    public void element()
    {
        int i=0;
        string matches ="";
        for(i=0;i<numbers.Length;i++)
        {
            if(numbers[i]==num)
            {
                matches+=i;
                matches+=" ";
            }
        }
        if(matches=="")
        {
            Console.Write("No Matches");
        }
        else
        {
            Console.WriteLine("Entry is stored within element/s: "+matches);
        }
    }   


}