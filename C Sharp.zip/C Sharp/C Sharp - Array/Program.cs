﻿using System;

namespace C_Sharp___Array
{
    class Program
    {
        static void Main(string[] args)
        {
           
            Console.Write("hellooooooooooooooooooooooooooooo");
            //Cities cities=new Cities();
            //cities.citylongestname();

        }
    }
}
