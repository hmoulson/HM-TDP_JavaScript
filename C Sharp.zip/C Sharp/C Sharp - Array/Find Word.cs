using System;

//class longestword
{
    //public void findword()
    {
        //string text = "Hello my name is";
       // int i=0,j=0,num=0;
        //for(i=0,i<text.Length,i++)
        {
            //if(text.Substring(i,1)==" ")
            {
                //if(i-j>num)
                {
                   // num=(i-j);
                }
            }
            //if(i==text.Length-1)
            {
               // if(i-j>num)
                {
                    //num=(i-j);
                }
            }

        }
        //Console.WriteLine(j);
    }
}
//public void findword(string message) print most characters

/*


dfg
s
dfg
sd
fg
sdf
gsd
fg
sdfg
sd
fg
sdg
sd



*/