using System;

class Cities
{
    string [] cities={"London","Manchester","Leeds","York","Bradford","Carlisle","Royal Leamington Spa"};
    int i=0;
    string longestname ="";
    public void citylongestname()
    {
        for(i=0;i<cities.Length;i++)
        {
            if(cities[i].Length>longestname.Length)
            {
                longestname=cities[i];
            }
        }
        Console.WriteLine(longestname);
    }

}