﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp___Abstract
{
    class HSBC:Bank
    {
        public override void accountOpen()
        {
            Console.WriteLine("This account has been opened by HSBC");
        }
        public override void showBalance()
        {
            Console.WriteLine("Your HSBC's Balance is");
        }
    }
}
