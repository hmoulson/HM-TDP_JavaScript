﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp___Abstract
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank hsbc = new HSBC();
            hsbc.accountOpen();
            hsbc.showBalance();


            Barclays barclays = new Barclays();
            barclays.accountOpen();
            barclays.showBalance();
            barclays.PendingTransactions();

            Console.Read();
        }
    }
}
