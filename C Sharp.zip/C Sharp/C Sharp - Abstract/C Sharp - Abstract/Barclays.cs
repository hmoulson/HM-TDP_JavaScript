﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp___Abstract
{
    class Barclays:Bank,ITransactions
    {
        public override void accountOpen()
        {
            Console.WriteLine("This account has been opened by Barclays");
        }
        public override void showBalance()
        {
            Console.WriteLine("Your Barclay's Balance is");
        }
        public void RecentTransaction()
        {
            Console.WriteLine("Your recent Transactions are:");
        }
        public void PendingTransactions()
        {
            Console.WriteLine("Your recent Transactions are:");
        }
    }
}
