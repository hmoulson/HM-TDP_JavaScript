﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp___Abstract
{
    abstract class Bank
    {
        public abstract void accountOpen();
        public abstract void showBalance();

    }
}
