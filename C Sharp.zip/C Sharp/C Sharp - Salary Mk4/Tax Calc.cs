using System;


class accounts
{
    public float Tax(int Salary)
    {
        int band;
        float rate,t;
        for(band=7000,rate=35,t=0;band>=2500;band-=1500,rate-=7)
        {
            if(Salary>band)
            {
                t+=(Salary-band)*(rate/100);
                Console.WriteLine(rate+"  -  "+t);
                Salary=band;
            }
            else
            {
                continue;
            }        
        }
        return t;
        
        }




}