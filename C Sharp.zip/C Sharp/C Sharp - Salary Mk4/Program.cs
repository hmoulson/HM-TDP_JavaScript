﻿using System;

namespace C_Sharp___Salary_Mk4
{
    class Program
    {
        static void Main(string[] args)
        {
            accounts acc=new accounts();
            int salary=10000;
            float net=0;
            net = salary-acc.Tax(salary);
            Console.WriteLine("Salary - "+salary);
            Console.WriteLine("Tax - "+acc.Tax(salary));
            Console.WriteLine("Net - "+net);

        }
    }
}
