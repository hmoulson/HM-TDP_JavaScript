﻿using System;

namespace C_Sharp___Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int count,multiplier;
            count=0;
            multiplier=0;
            Console.WriteLine("Starting");
            for (count=1,multiplier=5;count<=5;count=count+1,multiplier=multiplier*5){
                Console.WriteLine(count*multiplier);
            }
            Console.Write("Ending");
        }
    }
}
