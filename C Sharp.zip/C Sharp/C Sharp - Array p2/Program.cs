﻿using System;

namespace C_Sharp___Array_p2
{
    class Program
    {
        static void Main(string[] args)
        {
            /*string text = "Hello Worldie i am tempermental person";
            Longestword longestword=new Longestword();
            longestword.findword(text);

            HighestNumber highestNumber=new HighestNumber();
            highestNumber.bignumber();
            */

            NumtoText numtoText=new NumtoText();
            numtoText.Num2Alph(1727430);

        }
    }
}
