using System;

class Longestword
{
    public void findword(string text)
    {
        string countword="",longword="";
        int i=0;
        for(i=0;i<text.Length;i++)
        {
            if(text.Substring(i,1)==" ")
            {
                if(countword.Length>longword.Length)
                {
                    longword=(countword);
                }
                countword="";
            }
            countword+=text.Substring(i,1);

        }
        if(countword.Length>longword.Length)
            {
                longword=(countword);
            }
        countword="";
        Console.WriteLine("The Longest Word is "+longword);
    }
}

//public void findword(string message) print most characters