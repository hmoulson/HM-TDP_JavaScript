using System;

class NumtoText
{
    public void Num2Alph(int number)
    {
        string[] ones={"","one","two","three","four","five","six","seven","eight","nine","ten","eleven","twelve","thirteen","fourteen","fifeen","sixteen","seventeen","eighteen","nineteen"};
        string[] tens={"","","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
        string answer="";

        if(number>=1000000)
        { 
            Console.WriteLine("Number too big");
        }
        
        else
        {
            if(number>=1000)
            {
                if(number>=100000)
                {
                    answer+=ones[number/100000] + " hundred ";
                    number%=100000;
                }

                if(number>=1000)
                {
                    answer+="and ";
                    if(number>=20000&&number<100000)
                    {
                        answer+=tens[number/10000];
                        number%=10000;
                    }
                    
                    if(number>=1000&&number<20000)
                    {
                        answer+=ones[number/1000];
                        number%=1000;
                    }
                }
                answer+=" thousand ";
            }

            if(number>=100)
            {
                answer+=ones[number/100] + " hundred ";
                number%=100;
            }

            if(number>=1)
            {
                answer+="and ";
            }
            
            if(number>=20)
            {
                answer+=tens[number/10];
                number%=10;
            }

            if(number>=1)
            {
                answer+=ones[number];
            }
        }

        Console.WriteLine(answer);
    }
}