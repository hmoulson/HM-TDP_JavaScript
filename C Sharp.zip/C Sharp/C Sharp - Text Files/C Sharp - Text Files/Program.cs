﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;

namespace C_Sharp___Text_Files
{
    class Program
    {
        static void Main(string[] args)
        {
            string ReadText = File.ReadAllText(@"C:\Users\Admin\Desktop\CSharpText.txt");
            Deduplicating_Files deduplicating = new Deduplicating_Files();
            String NewText=deduplicating.dedup(ReadText);
            File.WriteAllText(@"C:\Users\Admin\Desktop\CSharpText2.txt", NewText);

                        
        }
    }
}
