﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___SQL_Banking
{
    class Program
    {
        static void Main(string[] args)
        {
            MySQL_Connector mySQL_Connector = new MySQL_Connector();
            int ch;
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Please type your choice");
                Console.WriteLine("1 - New Account");
                Console.WriteLine("2 - List of Account Holders");
                Console.WriteLine("3 - Update Account");
                Console.WriteLine("4 - Close Account");
                Console.WriteLine("5 - Aggregates");
                Console.WriteLine("");
                Console.WriteLine("0 - Exit Menu");
                ch = Int32.Parse(Console.ReadLine());

                if (ch >= 0 && ch <= 4)
                {
                    if (ch == 0)
                    {
                        break;
                    }

                    else if (ch == 1)
                    {
                        Console.Clear();
                        Banking banking = new Banking();
                        Console.WriteLine("To Create your Account, please answer the following:");
                        Console.WriteLine("Enter your name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Select your type of Account");
                        string AccountType = Console.ReadLine();
                        Console.WriteLine("Enter your City");
                        string Address = Console.ReadLine();
                        Console.WriteLine("Enter your Street Address");
                        Address = Console.ReadLine() + ", " + Address;
                        Console.WriteLine("Select your Country");
                        string Country = Console.ReadLine();

                        banking.createBankAccount(AccountType, name, Address, Country);
                        Console.Read();
                    }

                    else if (ch == 2)
                    {
                        int ch2;
                        while (true)
                        {
                            Console.Clear();
                            Console.WriteLine("Please type your choice");
                            Console.WriteLine("1 - All Accounts");
                            Console.WriteLine("2 - All Current Accounts");
                            Console.WriteLine("3 - All Savings Accounts");
                            Console.WriteLine("4 - All Accounts from England");
                            Console.WriteLine("5 - All Accounts from Scotland");
                            Console.WriteLine("6 - All Accounts from Wales");
                            Console.WriteLine("7 - All Accounts from Northern Ireland");
                            Console.WriteLine("8 - See Details of Specific Account");
                            Console.WriteLine("");
                            Console.WriteLine("0 - Return to First Menu");
                            ch2 = Int32.Parse(Console.ReadLine());
                            ViewAccounts view = new ViewAccounts();

                            if (ch2 <= 8 && ch2 >= 0)
                            {
                                if (ch2 == 1)
                                {
                                    view.AllAccounts();
                                }
                                else if (ch2 == 2 || ch2 == 3)
                                {
                                    string type = "";
                                    if (ch2 == 2)
                                    {
                                        type = "C";
                                    }
                                    else if (ch2 == 3)
                                    {
                                        type = "S";
                                    }
                                    string SQLFind = $"select * from bamnk where substring(accno,2,1)='{type}'";
                                    mySQL_Connector.showRecords(SQLFind);
                                }

                                else if (ch2 == 4 || ch2 == 5 || ch2 == 6 || ch2 == 7)
                                {
                                    string countrycode = "";
                                    if (ch2 == 4)
                                    {
                                        countrycode = "E";
                                    }
                                    else if (ch2 == 5)
                                    {
                                        countrycode = "S";
                                    }
                                    else if (ch2 == 6)
                                    {
                                        countrycode = "W";
                                    }
                                    else if (ch2 == 7)
                                    {
                                        countrycode = "N";
                                    }
                                    string SQLFind = $"select * from bamnk where substring(accno,1,1)='{countrycode}'";
                                    mySQL_Connector.showRecords(SQLFind);
                                }

                                else if (ch2 == 8)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Please select the Account information you wish to enter:");
                                    Console.WriteLine("1 - Account Number");
                                    Console.WriteLine("2 - Name");
                                    Console.WriteLine("3 - Address");
                                    int ch3 = Int32.Parse(Console.ReadLine());
                                    Search_Accounts search_Accounts = new Search_Accounts();
                                    if (ch3 == 1)
                                    {
                                        Console.WriteLine("Please enter the Account Number:");
                                        string accno = Console.ReadLine();
                                        string SQLFind = $"Select * from bank where accno = '{accno}'";
                                        mySQL_Connector.showRecords(SQLFind);
                                    }
                                    if (ch3 == 2)
                                    {
                                        Console.WriteLine("Please enter the Name of the Account Holder:");
                                        string name = Console.ReadLine();
                                        string SQLFind = $"Select * from bank where name = '{name}'";
                                        mySQL_Connector.showRecords(SQLFind);
                                    }
                                    if (ch3 == 3)
                                    {
                                        Console.WriteLine("Please enter the Address of the Account Holder:");
                                        string address = Console.ReadLine();
                                        string SQLFind = $"Select * from bank where address = '{address}'";
                                        mySQL_Connector.showRecords(SQLFind);
                                    }
                                }
                                else if (ch2 == 0)
                                {
                                    break;
                                }
                            }
                            else
                            {
                                continue;
                            }

                        }
                    }
                    else
                    {
                        continue;
                    }
                }



                if (ch == 3)
                {
                    Console.WriteLine("Please Select from the Following:");
                    Console.WriteLine("1 - Update Name");
                    Console.WriteLine("2 - Update Address");
                    Console.WriteLine("3 - Update Second Holder");

                }

                if (ch == 4)
                {
                    string ch4;
                    while (true)
                    {
                        Console.WriteLine("Please confirm you wish to delete an account:");
                        Console.WriteLine("Y - Yes");
                        Console.WriteLine("N - No");
                        Console.WriteLine("Z - Back to Main Menu");
                        ch4 = Console.ReadLine();
                        Delete Del = new Delete();

                        if (ch4 == "Y" || ch4 == "y")
                        {
                            while (true)
                            {
                                Console.WriteLine("Please enter the Account Number");
                                string accno = Console.ReadLine();
                                Console.Clear();
                                Console.WriteLine("Please confirm you wish to delete account " + accno);
                                Console.WriteLine("Y - Yes");
                                Console.WriteLine("N - No");
                                string ch5 = Console.ReadLine();

                                if (ch5 == "Y")
                                {
                                    string sqldelete = $"delete from bank where accno = '{accno}'";
                                    mySQL_Connector.showRecords(sqldelete);
                                }

                                else if (ch5 == "N" || ch5 == "n")
                                {
                                    break;
                                }

                                else
                                {
                                    continue;
                                }
                            }
                        }

                        else if (ch4 == "N" || ch4 == "Z" || ch4 == "n" || ch4 == "z")
                        {
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                }
                if (ch == 5)
                {
                    while (true)
                    {
                        Console.Clear();
                        Console.WriteLine("Please select the type of Aggregate desired");
                        Console.WriteLine("1 - Count");
                        Console.WriteLine("2 - Sum");
                        Console.WriteLine("3 - Average");
                        Console.WriteLine("4 - Max");
                        Console.WriteLine("5 - Min");
                        Console.WriteLine("0 - Exit to Last Menu");
                        int ch5 = Int32.Parse(Console.ReadLine());

                        if (ch5 == 0)
                        {
                            break;
                        }
                        else if (ch5 == 1)
                        {
                            string Count = $"select count(accno) from bank where ";
                            while (true)
                            {
                                Console.Clear();
                                Console.WriteLine("Please select the type of accounts to be counted");
                                Console.WriteLine("1 - All");
                                Console.WriteLine("2 - Current");
                                Console.WriteLine("3 - Savings");
                                int AccountType = Int32.Parse(Console.ReadLine());

                                if (AccountType == 1 || AccountType == 2 || AccountType == 3)
                                {
                                    if (AccountType == 1)
                                    {
                                        Count += "substr(accno,2,1)<>'' and ";
                                    }

                                    else if (AccountType == 2)
                                    {
                                        Count += "substr(accno,2,1)='C' and ";
                                    }
                                    else if (AccountType == 3)
                                    {
                                        Count += "substr(accno,2,1)='S' and ";
                                    }

                                }
                                else
                                {
                                    continue;
                                }
                                while (true)
                                {
                                    Console.Clear();
                                    Console.WriteLine("Please select the nation/s to be counted");
                                    Console.WriteLine("1 - All");
                                    Console.WriteLine("2 - England");
                                    Console.WriteLine("3 - Wales");
                                    Console.WriteLine("4 - Scotland");
                                    Console.WriteLine("5 - Northern Ireland");
                                    int Country = Int32.Parse(Console.ReadLine());

                                    if (Country == 1 || Country == 2 || Country == 3 || Country == 4 || Country == 5)
                                    {
                                        if (Country == 1)
                                        {
                                            Count += "substr(accno,1,1)<>''";
                                        }

                                        else if (Country == 2)
                                        {
                                            Count += "substr(accno,1,1)='E'";
                                        }
                                        else if (Country == 3)
                                        {
                                            Count += "substr(accno,1,1)='W'";
                                        }
                                        else if (Country == 4)
                                        {
                                            Count += "substr(accno,1,1)='S'";
                                        }
                                        else if (Country == 5)
                                        {
                                            Count += "substr(accno,1,1)='N'";
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }
                                    while (true)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Group by Country?");
                                        Console.WriteLine("Y - Yes");
                                        Console.WriteLine("N - No");
                                        string Group = Console.ReadLine();

                                        if (Group == "Y" || Group == "y") 
                                        {
                                            Count += " group by country;";
                                            Console.WriteLine(Count);
                                            mySQL_Connector.CountRecords(Count);
                                            Console.Read();
                                        }
                                        else if (Group == "N" || Group == "n")
                                        {
                                            Count += ";";
                                            Console.WriteLine(Count);
                                            mySQL_Connector.CountRecords(Count);
                                            Console.Read();
                                        }
                                        else
                                        {
                                            continue;
                                        }
                                    }   
                                }
                            }
                        }







                    }










                    /*
                    Exercises ex = new Exercises();

                    Console.WriteLine("Enter Number");
                    int num = Convert.ToInt32(Console.ReadLine());

                    ex.countdown(num);

                    Console.WriteLine("Your name is:");
                    string name = Console.ReadLine();

                    Console.WriteLine("Your age is:");
                    int age = Convert.ToInt32(Console.ReadLine());

                    Console.WriteLine("Your favourite pet is:");
                    string pet = Console.ReadLine();

                    ex.personal(name, age, pet);

                    */

                }
            }
        }
    }
}
