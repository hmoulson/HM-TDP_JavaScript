﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___SQL_Banking
{
    class Delete:MySQL_Connector
    {
        public void Delete_Account(string accno)
        {
            string sqldelete = $"delete from bank where accno = '{accno}'";
            showRecords(sqldelete);
        }
    }
}
