﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___SQL_Banking
{
    class MySQL_Connector
    {
        MySqlConnection sqlcon;
        MySqlCommand cmd;


        public MySQL_Connector()
        {
            string connectionstring = "server=localhost;user=root;password=root;database=library";
            sqlcon = new MySqlConnection(connectionstring);
            sqlcon.Open();
            cmd = new MySqlCommand();
            cmd.Connection = sqlcon;
        }

        public void showRecords(string sqlselect)
        {
            showRecordshidden(sqlselect);
        }
        
        private void showRecordshidden(string sqlselect)
        {
            cmd.CommandText = sqlselect;
            MySqlDataReader data = cmd.ExecuteReader();

            while (data.Read())
            {
                Console.WriteLine(data[0] + "......." + data[1] + "......." + data[2] + "......." + data[3]);
            }
            Console.WriteLine("Press any key to exit");
            Console.Read();

        }

        public void CountRecords (string sqlselect)
        {
            CountRecordshidden(sqlselect);
        }

        private void CountRecordshidden(string sqlselect)
        {
            cmd.CommandText = sqlselect;
            MySqlDataReader data = cmd.ExecuteReader();
            Console.WriteLine();
            
            Console.WriteLine("Press any key to exit");
            Console.Read();

        }
    }
}
