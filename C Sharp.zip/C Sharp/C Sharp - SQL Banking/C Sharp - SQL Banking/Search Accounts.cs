﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___SQL_Banking
{
    class Search_Accounts:MySQL_Connector
    {
        MySqlCommand cmd;
        MySqlConnection sqlcon;



        /*public Search_Accounts()
        {
            string connectionstring = "server=localhost;username=root;password=root;database=library";
            sqlcon = new MySqlConnection(connectionstring);
            sqlcon.Open();
            cmd = new MySqlCommand();
            cmd.Connection = sqlcon;

        }

        private void showRecords(string SQLSelect)
        {
            cmd.CommandText = SQLSelect;
            MySqlDataReader data = cmd.ExecuteReader();

            while (data.Read())
            {
                Console.WriteLine(data[0] + "......." + data[1] + "......." + data[2] + "......." + data[3]);
            }
            Console.WriteLine("Press any key to exit");
            Console.Read();
        }
        */
        public void byAccount(string Account)
        {
            string SQLFind = $"Select * from bank where accno = '{Account}'";
            showRecords(SQLFind);
        }

        public void byName(string Name)
        {
            string SQLFind = $"Select * from bank where name = '{Name}'";
            showRecords(SQLFind);
        }

        public void byAddress(string Address)
        {
            string SQLFind = $"Select * from bank where address = '{Address}'";
            showRecords(SQLFind);
        }

    }
}
