﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___SQL_Banking
{
    class Banking
    {
        MySqlConnection sqlcon;
        MySqlCommand cmd;
        MySqlCommand cmd2;

        public Banking()
        {
            string connectionstring = "server=localhost;user=root;password=root;database=library";
            sqlcon = new MySqlConnection(connectionstring);
            sqlcon.Open();
            cmd = new MySqlCommand();
            cmd.Connection = sqlcon;
            
        }


        public void createBankAccount(string accountType, string name, string address, string country)
        {
            string accountT = accountType.Substring(0, 1);

            cmd.CommandText = $"select lpad(ifnull(max(substr(accno,3,3))+1,1),3,'0') from bank where substr(accno,2,1)='{accountT}'";
            MySqlDataReader data = cmd.ExecuteReader();
            data.Read();
            string newaccountnumber = country.Substring(0, 1) + accountT + data[0];

            data.Close();
            cmd.CommandText = $"insert into bank values('{newaccountnumber}','{name}','{address}','{country}')";
            cmd.ExecuteNonQuery();

            Console.ReadLine();
            data.Close();

        }       

    }
}
