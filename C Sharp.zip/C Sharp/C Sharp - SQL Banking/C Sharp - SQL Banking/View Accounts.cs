﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C_Sharp___SQL_Banking
{
    class ViewAccounts:MySQL_Connector
    {
        /*
        MySqlConnection sqlcon;
        MySqlCommand cmd;

        public ViewAccounts()
        {
            string connectionstring = "server=localhost;user=root;password=root;database=library";
            sqlcon = new MySqlConnection(connectionstring);
            sqlcon.Open();
            cmd = new MySqlCommand();
            cmd.Connection = sqlcon;

        }

        private void Showrecords(string SQLselect)
        {
            cmd.CommandText = SQLselect;
            MySqlDataReader data = cmd.ExecuteReader();
            while (data.Read())
            {
                Console.WriteLine(data[0] + "......." + data[1] + "......." + data[2] + "......." + data[3]);
            }
            Console.WriteLine("Press any key to quit");
            Console.Read();

        }
        */

        public void AllAccounts()
        {
            string SQLSelect = $"Select * from bank";
            showRecords(SQLSelect);
        }

        public void AccountTypes(string type)
        {
            string SQLSelect = $"Select * from bank where substr(accno,2,1)='{type}'";
            showRecords(SQLSelect);
        }

        public void AccountOrigin(string country)
        {
            string SQLSelect = $"Select * from bank where substr(accno,1,1)='{country}'";
            showRecords(SQLSelect);
        }

    }
}
