﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp___SQL_Banking
{
    class Exercises
    {
        public void countdown(int startnum)
        {
            int i = startnum;
            for(;i>0; i--)
            {
                Console.WriteLine("Countdown: " + i);
            }
            Console.WriteLine("Countdown: Done!");
        }

        public void personal(string name,int age,string pet)
        {
            Console.WriteLine("My name is " + name + ", I am " + age + " years old and my favourite pet is a " + pet);
            Console.Read();
        }
    }
}
