﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

/*
namespace C_Sharp___SQL_Banking
{
    class Original_Main
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please type your choice");
            Console.WriteLine("1 - New Account");
            Console.WriteLine("2 - List of Account Holders");
            Console.WriteLine("3 - Update Account");
            Console.WriteLine("4 - Close Account");
            int ch = Int32.Parse(Console.ReadLine());

            if (ch == 1)
            {
                Banking banking = new Banking();
                Console.WriteLine("Enter your name:");
                string name = Console.ReadLine();
                Console.WriteLine("Select your type of Account");
                string AccountType = Console.ReadLine();
                Console.WriteLine("Enter your City");
                string Address = Console.ReadLine();
                Console.WriteLine("Enter your Street Address");
                Address = Console.ReadLine() + ", " + Address;
                Console.WriteLine("Select your Country");
                string Country = Console.ReadLine();

                banking.createBankAccount(AccountType, name, Address, Country);
                Console.Read();
            }

            else if (ch == 2)
            {
                Console.WriteLine("Please type your choice");
                Console.WriteLine("1 - All Accounts");
                Console.WriteLine("2 - All Current Accounts");
                Console.WriteLine("3 - All Savings Accounts");
                Console.WriteLine("4 - All Accounts from England");
                Console.WriteLine("5 - All Accounts from Scotland");
                Console.WriteLine("6 - All Accounts from Wales");
                Console.WriteLine("7 - All Accounts from Northern Ireland");
                Console.WriteLine("8 - See Details of Specific Account");
                Console.WriteLine("");
                Console.WriteLine("0 - Return to First Menu");
                int ch2 = Int32.Parse(Console.ReadLine());

                if (ch2 == 1)
                {
                    ViewAccounts view = new ViewAccounts();
                    view.AllAccounts();
                }
                if (ch2 == 2 || ch2 == 3)
                {
                    string type = "";
                    if (ch2 == 2)
                    {
                        type = "C";
                    }
                    else if (ch2 == 3)
                    {
                        type = "S";
                    }
                    ViewAccounts view = new ViewAccounts();
                    view.AccountTypes(type);
                }

                if (ch2 == 4 || ch2 == 5 || ch2 == 6 || ch2 == 7)
                {
                    string countrycode = "";
                    if (ch2 == 4)
                    {
                        countrycode = "E";
                    }
                    else if (ch2 == 5)
                    {
                        countrycode = "S";
                    }
                    else if (ch2 == 6)
                    {
                        countrycode = "W";
                    }
                    else if (ch2 == 7)
                    {
                        countrycode = "N";
                    }
                    ViewAccounts view = new ViewAccounts();
                    view.AccountOrigin(countrycode);
                }

                if (ch2 == 8)
                {
                    Console.WriteLine("Please select the Account information you wish to enter:");
                    Console.WriteLine("1 - Account Number");
                    Console.WriteLine("2 - Name");
                    Console.WriteLine("3 - Address");
                    int ch3 = Int32.Parse(Console.ReadLine());
                    Search_Accounts search_Accounts = new Search_Accounts();
                    if (ch3 == 1)
                    {
                        Console.WriteLine("Please enter the Account Number:");
                        string accno = Console.ReadLine();
                        search_Accounts.byAccount(accno);
                    }
                    if (ch3 == 2)
                    {
                        Console.WriteLine("Please enter the Name of the Account Holder:");
                        string name = Console.ReadLine();
                        search_Accounts.byName(name);
                    }
                    if (ch3 == 3)
                    {
                        Console.WriteLine("Please enter the Address of the Account Holder:");
                        string address = Console.ReadLine();
                        search_Accounts.byAddress(address);
                    }
                }
            }
        }
    }
}
*/

        

    

