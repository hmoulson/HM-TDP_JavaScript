﻿using System;

namespace C_Sharp___Salary
{
    class Program
    {
        static void Main(string[] args)
        {
            float Tax,Net;
            int salary;
            salary=400;
            Tax=0;
            Net=0;
            if(salary>=2000){
                Tax=(float) 0.25*salary;
                Net=(float) salary-Tax;
            }
            else if(salary>=1000){
                Tax=(float) 0.15*salary;
                Net=(float) salary-Tax;
            }
            else {
                Tax=(float) 0*salary;
                Net=(float) salary-Tax;
            }
            Console.Write("Salary is ");
            Console.WriteLine(salary);
            Console.Write("Tax is ");
            Console.WriteLine(Tax);
            Console.Write("Take Home Pay is ");
            Console.WriteLine(Net);
        }
    }
}
