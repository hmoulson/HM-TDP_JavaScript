﻿using System;

namespace C_Sharp___Salary_Mk3
{
    class Program
    {
        public static void Main(string[] args)
        {
            Month m=new Month();
            salaryslip s=new salaryslip();
            s.salaryslipfunction("James",30000);
            Console.WriteLine("-------------");
            s.salaryslipfunction("Ryann",42500);
            Console.WriteLine("-------------");
            s.salaryslipfunction("Laura",34000);
            Console.WriteLine("-------------");
        }
    }
}
