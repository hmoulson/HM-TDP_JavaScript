using System;

class salaryslip
{
    public void salaryslipfunction(string name,int wage)
    {
        float tax,net;
        tax=0;
        net=0;
        if(wage>=41500)
        {
            tax=wage*35/100;
        }
        
        else if(wage>=32000)
        {
            tax=wage*25/100;
        }
        
        else
        {
            tax=wage*15/100;
        }
        net=wage-tax;
        Console.WriteLine("Salary Slip for "+name);
        Console.WriteLine("Salary is "+wage);
        Console.WriteLine("Tax is "+tax);
        Console.WriteLine("Take Home Pay is "+net);

    }
}