﻿using System;

namespace C_Sharp___Temperature
{
    class Program
    {
        static void Main(string[] args)
        {
            int Temp;
            Temp=30;
            if(Temp>40){
                Console.Write("hot");         
            }
            if(Temp<=40){
                Console.Write("cold");
            }
        }
    }
}
