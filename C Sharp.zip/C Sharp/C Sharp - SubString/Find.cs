using System;

class FindingSpaces
{
    int i=0;
    public void numberofwords(string text)
    {
        int space = 0;
        for(i=0;i<text.Length;i++)
        {
            if(text.Substring(i,1)==" ")
            {
                space++;
            }
        }
        Console.WriteLine("Number of words is "+space);
        Console.WriteLine("");

    }
    
    
    public void spacesearch(string text)
    {
        for(i=0;i<text.Length;i++)
        {
            if(text.Substring(i,1)==" ")
            {
                Console.Write(i+" ");
            }
        }
        Console.WriteLine(" ");


    }

    public void printvertically_int(string text)
    {
        int j=0;
        for(i=0;i<text.Length;i++)
        {
            if(text.Substring(i,1)==" ")
            {
                Console.WriteLine(text.Substring(j,(i-j)));
                j=i+1;
            }
            if(i==text.Length-1)
            {
                Console.WriteLine(text.Substring(j,(i+1-j)));
            }
        }
        Console.WriteLine(" ");
    }

    public void printvertically_string(string text)
    {
        string word="";
        for(i=0;i<text.Length;i++)
        {
            if(text.Substring(i,1)==" ")
            {
                Console.WriteLine(word);
                word="";
            }
            else
            {
                word+=text.Substring(i,1);
            }
        }
        Console.WriteLine(word);
        Console.WriteLine(" ");
    }

    public void printverticallyreverse_string(string text)
    {
        string word="";
        for(i=(text.Length-1);i>=0;i--)
        {
            if(text.Substring(i,1)==" ")
            {
                Console.WriteLine(word);
                word="";
            }
            else
            {
                word=text.Substring(i,1)+word;
            }
        }
        Console.WriteLine(word);
        Console.WriteLine(" ");
    }

    public void find(string text,string find)
    {
        int count=0;
        Console.Write("Locations: ");
        for(i=0;i<=(text.Length-find.Length);i++)
        {
            if(text.Substring(i,find.Length)==find)
            {
                count++;
                Console.Write(i+" ");
            }
        }
        Console.WriteLine(" ");
        Console.Write("Number of times '"+find+"' appears is: "+count);
        Console.WriteLine(" ");
    }

    public void findimp1(string text,string find)
    {
        int count = 0;
        int i =0;
        for(;i<text.Length;i++)
        {
            Console.Write(i+" ");
            if(text.Substring(i,1)==find.Substring(0,1))
            {
                if(text.Substring(i,find.Length)==find)
                {
                    count++;
                    i+=find.Length-1;
                }    
            }
        }
        Console.WriteLine("");
        Console.WriteLine(count);

    }
        
    public void findimp2(string text,string findimp)
    {
        int count=0;
        int j=1;
        for(i=0;i<=(text.Length-findimp.Length);i++)
        {
            Console.Write(i+" ");
            j=1;
            if(text.Substring(i,j)==findimp.Substring(0,j))
            {
                for(j=1;j<=findimp.Length;j++)
                {    
                    if(text.Substring(i,j)==findimp.Substring(0,j))
                    {
                        if(j==findimp.Length)
                        {
                            count++;
                            i=i+j-2;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        i=i+j-2;
                        break;
                    }
                }
            }
            else
            {
                continue;
            }
        }
        Console.WriteLine(" ");
        Console.Write("Number of times '"+findimp+"' appears is: "+count);
    }   
}