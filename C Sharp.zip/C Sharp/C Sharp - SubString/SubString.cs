using System;

class Substring

{
    //int i = 0;
                    
    //public void substring(string text)
    //{
        //for(i=0;i<=(text.Length);i++)
        //{
            //Console.WriteLine(text.Substring(i,1));
        //}
    //}
}