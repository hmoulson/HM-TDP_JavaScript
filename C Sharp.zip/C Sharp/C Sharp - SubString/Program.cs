﻿using System;

namespace C_Sharp___SubString
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "It was the best time of ttttttttttuimes for titimetables, it was the worst time of times for timetables";
            string search ="timetables";
            FindingSpaces findingSpaces=new FindingSpaces();
            //findingSpaces.numberofwords(text);
            //findingSpaces.spacesearch(text);
            //findingSpaces.printvertically_int(text);
            //findingSpaces.printvertically_string(text);
            //findingSpaces.printverticallyreverse_string(text);
            //findingSpaces.find(text,search);
            findingSpaces.findimp1(text,search);
        
        }
    }
}
