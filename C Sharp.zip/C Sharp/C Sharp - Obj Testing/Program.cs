﻿using System;

namespace C_Sharp___Obj_Testing
{
    class Program
    {
        static void Main(string[] args)
        {
            London T;
            T=new London();
            Belulia S;
            S=new Belulia();
            First R;
            R=new First();

            T.A=68;
            T.B=41;
            S.M=21;
            S.N=34;
            R.D=106;

            Console.WriteLine("A="+T.A);
            Console.WriteLine("B="+T.B);
            Console.WriteLine("M="+S.M);
            Console.WriteLine("N="+S.N);

            Console.WriteLine(T.A+T.B);
            Console.WriteLine(S.M+S.N);

            Console.WriteLine("D="+R.D);
            R.method();
        }
    }
   
    class London
    {
        public int A,B;

    }

    class Belulia
    {
        public int M,N;
    }

    class First
    {
        public int D;
        public void method()
        {
            Console.WriteLine("Hello,");
            Console.Write("Today is ");
            Console.Write("Tuesday");
            Console.WriteLine(T.A+S.N);
        }
    }
}