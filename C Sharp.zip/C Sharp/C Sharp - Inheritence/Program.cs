﻿using System;

namespace C_Sharp___Inheritence
{
    class Program
    {
        int Bubbles;
        static void Main(string[] args)
        {
            //NBS_Maths2 N=new NBS_Maths2();
            //N.Addition(42,17);
            //N.subtraction(42,17);
            //N.Multiplication(42,17);

            Bubbles=72;
            
            
            shadowing s=new shadowing();
            s.data();
            s.showdata();

        }
    }
    class shadowing
    {
        int A=5;

        public void data()
        {
            int A = 15;
            this.A=21;
            Console.WriteLine(A);
            Console.WriteLine(this.A);

        }
        public void showdata()
        {
            Console.WriteLine(A);
        }

    }
}
