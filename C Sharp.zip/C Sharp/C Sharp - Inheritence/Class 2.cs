using System;

class NBS_Maths2:NBS_Math
{
    int C=12;
    public void Addition(int A,int B)
    {
        Console.Write("Result is: ");
        Console.WriteLine(A+B);

    }

     public void Multiplication(int A,int B)
    {
        Console.Write("Result is: ");
        Console.WriteLine(A*B*C);
    }



}