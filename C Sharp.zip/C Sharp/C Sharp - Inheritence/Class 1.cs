using System;

class NBS_Math
{
    public void Addition(int A, int B)
    {
        Console.WriteLine(A+B);
    }

    public void subtraction(int A,int B)
    {
        Console.Write("Result is: ");
        Console.WriteLine(A-B);
    }





}