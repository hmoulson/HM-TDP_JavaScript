using System;

class NBSAccounts
{
    public void Tax()
    {
        Console.WriteLine(23); 
    }




}