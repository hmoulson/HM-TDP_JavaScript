﻿using System;

namespace shafeeq
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayBasic t=new ArrayBasic();

            t.StarterArray();
        }
    }
}
