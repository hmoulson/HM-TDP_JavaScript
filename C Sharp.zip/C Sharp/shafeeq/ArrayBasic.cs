using System;


class ArrayBasic
{
    public int[] numbers = {-9,9,-64,-97,-79,-83,-158,-68,-76,-86,-68,-78,-9,-108,-104};
    public int firnum;
    public int secnum;

    public void StarterArray()
    {
        Console.WriteLine("testing");
      
        firnum=numbers[0];
        
        secnum=numbers[1];
        int i=0;
        for(;i<numbers.Length;i++)
        {
            if(numbers[i]>firnum)
            {
                secnum=firnum;
                firnum=(numbers[i]);
            }
            else if(numbers[i]>secnum  && numbers[i]<firnum)
            {
                secnum=(numbers[i]);
                
            }
        }
        Console.WriteLine("largest value - "+firnum);
        Console.WriteLine("second value - "+secnum);
    }
/*
    public void element()
    {
        int i=0;
        string matches ="";
        for(i=0;i<numbers.Length;i++)
        {
            if(numbers[i]==firnum)
            {
                matches+=i;
                matches+=" ";
            }
        }
        if(matches=="")
        {
            Console.Write("No Matches");
        }
        else
        {
            Console.WriteLine("Entry is stored within element/s: "+matches);
        }
    }   
*/

}