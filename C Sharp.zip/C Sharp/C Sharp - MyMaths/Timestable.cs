using System;

class Timestable
{
    public Timestable(int num,int bottom,int top)
    {
        int count=0;

        for(;;count++)
        {  
            if(count<bottom)
            {  
                continue;
            }
            
            if(count>top)
            {
                break;
            }
            
            Console.Write(count+" x "+num+" = ");
            Console.WriteLine(num*count);
        }


    }


}