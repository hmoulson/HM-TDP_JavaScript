﻿using System;

namespace C_Sharp___MyMaths
{
    class MyMaths
    {
        static void Main(string[] args)
        {
            int number=87;
            int lowerbound=123;
            int higherbound=138;
          
            Timestable t=new Timestable(number,lowerbound,higherbound);
        }
    }
}
