﻿using System;

namespace C_Sharp___Visio_Studio_Playbox
{
    class Program
    {
        static void Main(string[] args)
        {
            int Num1 = 24;
            int Num2 = 17;
            
            Maths maths = new Maths();
            maths.multiplication(Num1, Num2);
        }
    }
}
