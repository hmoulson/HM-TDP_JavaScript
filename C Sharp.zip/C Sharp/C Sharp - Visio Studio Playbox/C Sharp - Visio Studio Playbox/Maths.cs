﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp___Visio_Studio_Playbox
{
    class Maths
    {
        public void multiplication(int a, int b)
            {
            Console.WriteLine(a*b);    
        }
    }
}
