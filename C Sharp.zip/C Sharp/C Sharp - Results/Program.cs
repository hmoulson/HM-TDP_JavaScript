﻿using System;

namespace C_Sharp___Results
{
    class Program
    {
        static void Main(string[] args)
        {
            Results Graham;
            Graham = new Results();

            Console.WriteLine("");
            Console.WriteLine("Graham Results");
            Graham.Physics(120);
            Graham.Chemistry(140);
            Graham.Mathematics(134);
            Graham.showResults();

            Results Laurie;
            Laurie = new Results();

            Console.WriteLine("");
            Console.WriteLine("Laurie Results");
            Laurie.Physics(119);
            Laurie.Chemistry(127);
            Laurie.Mathematics(114);
            Laurie.showResults();
        }    
    }
}
