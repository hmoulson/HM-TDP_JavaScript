
using System;

class Results
{
    private int phy,chem,math;
    private float total,perc;

    public void Physics(int mark)
    {
        if(mark>=0 && mark<=150)
        {
            phy=mark;
        }
        else
        {
            Console.WriteLine("Invalid Physics Mark");
        }
    }
    public void Chemistry(int mark)
    {
        if(mark>=0 && mark<=150)
        {
            chem=mark;
        }
        else
        {
            Console.WriteLine("Invalid Chemistry Mark");
        }
    }

    public void Mathematics(int mark)
    {
        if(mark>=0 && mark<=150)
        {
            math=mark;
        }
        else
        {
            Console.WriteLine("Invalid Chemistry Mark");
        }
    }

    public void showResults()
    {
        total=phy+chem+math;
        perc=total/450*100;
        Console.WriteLine("Total Marks is "+total);
        Console.WriteLine("Percentage Score is "+perc);

    }



}