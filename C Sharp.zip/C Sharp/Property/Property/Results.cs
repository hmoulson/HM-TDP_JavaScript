﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Property
{
    class Results
    {
        private int phy;
       
        public int physics
        {
            set
            {
                Console.WriteLine("Your entered value is " + value);
                if (value >= 0 && value <= 100)
                {
                    phy = value;
                }
                else
                {
                    Console.WriteLine("Your Mark does not comply with grading boundaries");
                }
            }
            get 
            {
                return phy;
            }
        }

        public float percentage
        {
            get
            {
                float per = phy * 100 / 150;
                return per;
            }
        }
    }
}
