﻿using System;

namespace Property
{
    class Program
    {
        static void Main(string[] args)
        {
            Results results = new Results();

            results.physics = 90;
            Console.WriteLine("Your Physics Mark is " + results.physics);
            Console.WriteLine("Your Percentage is " + results.percentage);
            Console.Read();
        }
    }
}
