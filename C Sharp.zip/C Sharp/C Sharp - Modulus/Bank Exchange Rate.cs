using System;

class BankExchangeRate
{
    static public int Dollar;

    public void setDollar(int amo)
    {
        Dollar=amo;
    }

    public void ConvertCurrency(int currency)
    {
        Console.WriteLine("The Value is: "+currency*Dollar);
    }
}