using System;

class Switch
{
    public void check(int day)
    {
        switch(day)
        {
            case 1: 
            case 3: 
            case 5: Console.WriteLine("Take Inventory"); break;
            case 2: 
            case 4: Console.WriteLine("Generate Reports"); break;
            case 6: Console.WriteLine("No Tasks"); break;
            case 7: Console.WriteLine("Run Week-End Reports"); break;

        }

    }
    
}