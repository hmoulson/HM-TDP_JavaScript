﻿using System;

namespace C_Sharp___Modulus
{
    class Program
    {
        static void Main(string[] args)
        {
           // Switch s=new Switch();
           // int Day=0;
           // for(Day=1;Day<=7;Day++)
           // {
               // Console.Write("Day "+Day+" - ");
               // s.check(Day);
           // }


           // NumberstoEnglish nte=new NumberstoEnglish();
           // int entry = 57;
           // Console.Write(entry+"  -  ");
           // nte.response(entry);

           BankExchangeRate HSBC,Natwest,Nationwide;
           Natwest=new BankExchangeRate();
           Nationwide=new BankExchangeRate();
           HSBC=new BankExchangeRate();

           Nationwide.setDollar(3);
           HSBC.ConvertCurrency(200);
           Natwest.ConvertCurrency(170);
           Nationwide.ConvertCurrency(240);
           
        }
    }
}
