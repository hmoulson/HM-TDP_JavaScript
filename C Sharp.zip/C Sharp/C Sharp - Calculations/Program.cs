﻿using System;

namespace C_Sharp___Calculations
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int c;
            a=10;
            b=20;
            c=a+b;
            Console.WriteLine("Your Result is");
            Console.WriteLine(c);
                    }
    }
}
